// 生产环境配置
const CONFIG = {
    envId: 'new-travel-2gy6d6oy7ee5fb0e',
    apiKey: '', // 生产环境需要配置正确的API密钥
    baseUrl: 'https://api.weixin.qq.com',
    useProxy: false, // 生产环境直接调用微信API
    isProduction: true
};

// 导出配置
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CONFIG;
} else if (typeof window !== 'undefined') {
    window.CONFIG = CONFIG;
}
