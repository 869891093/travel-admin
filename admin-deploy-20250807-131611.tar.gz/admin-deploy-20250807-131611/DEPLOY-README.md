# 网页管理系统部署说明

## 快速部署

### 1. 上传文件
将整个文件夹上传到服务器

### 2. 安装依赖
```bash
npm install
```

### 3. 启动服务
```bash
# 方式1：直接启动
node server.js

# 方式2：使用PM2（推荐）
npm install -g pm2
pm2 start server.js --name "admin-server"
pm2 startup
pm2 save
```

### 4. 配置域名（可选）
```nginx
server {
    listen 80;
    server_name your-domain.com;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

## 访问地址
- 主页面：http://your-server-ip:3000
- 测试页面：http://your-server-ip:3000/test-product-edit.html

## 功能特性
- ✅ 产品管理（增删改查）
- ✅ 图片上传功能
- ✅ 价格日历管理
- ✅ 行程安排管理
- ✅ 费用说明管理
- ✅ 预订须知管理
- ✅ 标签管理
- ✅ 响应式设计

## 注意事项
1. 确保服务器已安装 Node.js (>= 14)
2. 确保端口3000未被占用
3. 生产环境建议配置SSL证书
4. 定期备份数据
