#!/bin/bash

echo "🚀 启动网页管理系统..."

# 检查Node.js
if ! command -v node &> /dev/null; then
    echo "❌ 错误：Node.js未安装"
    exit 1
fi

# 安装依赖
if [ ! -d "node_modules" ]; then
    echo "📥 安装依赖..."
    npm install
fi

# 启动服务
echo "✅ 启动服务..."
node server.js
